Synergine howto project: LifeGame
=============

Work in progress ...

