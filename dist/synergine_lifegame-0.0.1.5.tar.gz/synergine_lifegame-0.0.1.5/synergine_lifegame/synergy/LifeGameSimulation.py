from synergine.synergy.Simulation import Simulation


class LifeGameSimulation(Simulation):
    """
    Life game simulation container.
    """
    pass  # Nothing to do here